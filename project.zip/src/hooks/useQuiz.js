import { useState, useEffect } from "react";
import { testGenerate } from "../utils/testGenerate";

/**
 * Custom hook that manages quiz logic:
 * - generates questions
 * - tracks current question
 * - calculates score
 * - handles quiz completion
 *
 * @param {Object} params
 * @param {Object} params.settings - Quiz settings (difficulty, count)
 * @param {"easy"|"medium"|"hard"} params.settings.difficulty
 * @param {number} params.settings.count
 * @param {Function} params.onFinish - Callback when quiz is finished
 * @param {string|number} params.testKey - Key to regenerate quiz
 *
 * @returns {Object} Quiz state and handlers
 * @returns {Object|null} returns.question - Current question
 * @returns {number} returns.score - Current score
 * @returns {Function} returns.setScore - Manually set score
 * @returns {number} returns.currentIndex - Current question index
 * @returns {number} returns.total - Total questions count
 * @returns {boolean} returns.isLast - Is current question last
 * @returns {Function} returns.doAnswer - Handle answer selection
 * @returns {Function} returns.finishQuiz - Force finish quiz
 */


export function useQuiz({ settings, onFinish, testKey }) {
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (settings) 
    {
      const generated = testGenerate(settings.difficulty, settings.count);
      setQuestions(generated);
      setCurrentIndex(0);
      setScore(0);
    }
  }, [settings, testKey]);

  const total = questions.length;
  const question = total > 0 ? questions[currentIndex] : null;
  const isLast = currentIndex === total - 1;

  /**
 * Handles answer selection and updates score.
 *
 * @param {number} selected - Selected answer option
 */
  function doAnswer(selected) 
  {
    if (!question) 
      return;

    const correct = selected === question.answer;
    const newScore = score + (correct ? 1 : 0);
    setScore(newScore);

    if (isLast) 
    {
      onFinish(newScore);
    } 
    else 
      {
      setCurrentIndex((i) => i + 1);
    }
  }

  /**
 * Forces quiz completion and triggers onFinish callback.
 */
  function finishQuiz() 
  {
    if (onFinish) 
      onFinish(score);
  }

  return {
    question,
    score,
    setScore,
    currentIndex,
    total,
    isLast,
    doAnswer,
    finishQuiz,
  };
}
